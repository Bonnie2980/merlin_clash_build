#!/bin/sh

export KSROOT=/jffs/softcenter
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'

if [ "$merlinclash_enable" == "1" ]; then
    #echo_date "开始检查进程状态..."
    a=$(ps | grep httpd | grep -v grep | grep -v httpds | grep -v httpdb | awk '{print $1}')
    if [ ! -n "$a" ]; then
        service restart_httpd
    fi
    if [ ! -n "$(pidof clash)" ]; then
        #先执行清除缓存
        sync
	    echo 1 > /proc/sys/vm/drop_caches
        sleep 1s
        sh /jffs/softcenter/merlinclash/clashconfig.sh restart >/dev/null 2>&1 &
    #    echo_date "重启 Clash 进程"
    fi
fi
