#!/bin/sh

export KSROOT=/jffs/softcenter
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#

ln -sf /jffs/softcenter/merlinclash/koolproxy/data/rules/user.txt /tmp/user.txt
if [ -f "/jffs/softcenter/merlinclash/yaml_basic/routerrules.yaml" ]; then
   ln -sf /jffs/softcenter/merlinclash/yaml_basic/routerrules.yaml /tmp/clash_routerrules.txt 
fi


