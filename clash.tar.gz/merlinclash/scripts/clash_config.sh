#!/bin/sh

export KSROOT=/jffs/softcenter
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/merlinclash_log.txt
SIMLOG_FILE=/tmp/merlinclash_simlog.txt
rm -rf /tmp/merlinclash_log.txt
rm -rf $SIMLOG_FILE
echo "" > /tmp/merlinclash_log.txt
echo "" > $SIMLOG_FILE
get(){
	a=$(echo $(dbus get $1))
	a=$(echo $(dbus get $1))
	echo $a
}

mcenable=$(get merlinclash_enable)
mkenable=$(get merlinclash_koolproxy_enable)
action=$(get merlinclash_action)

case $action in
0)
	sh /jffs/softcenter/merlinclash/clashconfig.sh stop >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> $SIMLOG_FILE
	;;
1)
	echo start >> /tmp/merlinclash_log.txt
	sh /jffs/softcenter/merlinclash/clashconfig.sh restart >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> $SIMLOG_FILE
	;;
3)
	#echo upload >> /tmp/merlinclash_log.txt
	sh /jffs/softcenter/merlinclash/clashconfig.sh upload
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	;;
34)
	if [ "$mcenable" == "1" ];then
		echo "快速重启" >> /tmp/merlinclash_log.txt
		sh /jffs/softcenter/merlinclash/clashconfig.sh quicklyrestart >> /tmp/merlinclash_log.txt
	else
		echo "请先启用merlinclash" >> /tmp/merlinclash_log.txt		
	fi
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> $SIMLOG_FILE
	;;
33)
	if [ "$mcenable" == "1" ];then
		echo "重建iptables" >> /tmp/merlinclash_log.txt
		sh /jffs/softcenter/merlinclash/clashconfig.sh start_nat >> /tmp/merlinclash_log.txt
	else
		echo "请先启用merlinclash" >> /tmp/merlinclash_log.txt		
	fi
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> $SIMLOG_FILE
	;;
44)
	sh /jffs/softcenter/scripts/clash_dnsmasqrestart.sh >> /tmp/upload/merlinclash_log.txt
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	echo BBABBBBC >> $SIMLOG_FILE
	;;
8)
	if [ "$mcenable" == "1" ];then
		echo "网易云音乐解锁快速重启" >> /tmp/merlinclash_log.txt
		sh /jffs/softcenter/scripts/clash_unblockneteasemusic.sh restart
	else
		echo "请先启用merlinclash" >> /tmp/merlinclash_log.txt		
	fi
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	;;
40)
	if [ "$mcenable" == "1" ] && [ "$mkenable" == "1" ];then
		echo "KoolProxy重启" >> /tmp/merlinclash_log.txt
		sh /jffs/softcenter/scripts/clash_koolproxyconfig.sh restart
	else
		if [ "$mcenable" != "1" ]; then
			echo "请先启用merlinclash" >> /tmp/merlinclash_log.txt	
		fi
		if [ "$mkenable" != "1" ]; then
			echo "请先启用koolproxy" >> /tmp/merlinclash_log.txt	
		fi	
	fi
	echo BBABBBBC >> /tmp/merlinclash_log.txt
	;;
esac