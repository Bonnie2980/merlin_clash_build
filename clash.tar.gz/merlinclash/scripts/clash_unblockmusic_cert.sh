#!/bin/sh

source /jffs/softcenter/scripts/base.sh
eval `dbus export merlinclash_`

filepath=/jffs/softcenter/bin/UnblockMusic
filename=ca.crt

mkdir -p /var/wwwext
ln -sf /var/wwwext /www/ext

cp -rf $filepath/$filename /www/ext/$filename

