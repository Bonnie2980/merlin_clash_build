#!/bin/sh

export KSROOT=/jffs/softcenter
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
#
rm -rf /tmp/clash_script_view.txt
ln -sf /jffs/softcenter/merlinclash/yaml_basic/script.yaml /tmp/clash_script_view.txt




