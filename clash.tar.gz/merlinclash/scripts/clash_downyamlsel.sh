#!/bin/sh

export KSROOT=/jffs/softcenter
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/merlinclash_log.txt

echo_date "download" >> $LOG_FILE
echo_date "定位文件" >> $LOG_FILE
yamlpath=/jffs/softcenter/merlinclash/yaml_use
tmp_path=/tmp/
get(){
	a=$(echo $(dbus get $1))
	a=$(echo $(dbus get $1))
	echo $a
}
action=$(get merlinclash_action)
yamlsel=$(get merlinclash_delyamlsel)
downyamlfile(){
    filename=$(echo $yamlsel.yaml)
    echo_date "$filename" >> $LOG_FILE

    cp -rf $yamlpath/$filename /www/ext/${merlinclash_delyamlsel}.htm
    if [ -f /www/ext/${merlinclash_delyamlsel}.htm ]; then
    echo_date "文件已复制" >> $LOG_FILE

    else
        echo_date "文件复制失败" >> $LOG_FILE
    fi
}

case $action in
37)
    downyamlfile
	;;
esac
