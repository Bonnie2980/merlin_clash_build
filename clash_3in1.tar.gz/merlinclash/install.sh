#! /bin/sh

eval $(dbus export merlinclash)
source /jffs/softcenter/scripts/base.sh
source helper.sh
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
MODEL=$(nvram get productid)
LINUX_VER=$(uname -r|awk -F"." '{print $1$2}')

mkdir -p /jffs/softcenter/merlinclash
mkdir -p /tmp/upload
sleep 2s
get(){
	a=$(echo $(dbus get $1))
	a=$(echo $(dbus get $1))
	echo $a
}
me=$(get merlinclash_enable)


firmware_version=`dbus get softcenter_firmware_version`
#api1.5
firmware_check=5.1.2
firmware_comp=`/jffs/softcenter/bin/versioncmp $firmware_version $firmware_check`
if [ "$firmware_comp" == "1" ];then
	echo_date 1.5代api最低固件版本为5.1.2,固件版本过低，无法安装
	exit 1
fi

# 判断路由架构和平台
case $(uname -m) in
	aarch64)
		echo_date 固件平台【merlin armv8】符合安装要求，开始安装插件！
		;;
	armv7l)
		echo_date 固件平台【merlin armv7l】符合安装要求，开始安装插件！
		;;
	*)
		exit_install 1
	;;
esac

exit_install(){
	local state=$1
	case $state in
		1)
			
			echo_date "退出安装！"
			rm -rf /tmp/*.tar.gz >/dev/null 2>&1
			exit 1
			;;
		0|*)
			rm -rf /tmp/*.tar.gz >/dev/null 2>&1
			exit 0
			;;
	esac
}
#升级前先删除无关文件,保留已上传配置文件
# 检测储存空间是否足够
echo_date 检测jffs分区剩余空间...
SPACE_AVAL=$(df|grep jffs|head -n 1 | awk '{print $4}')
SPACE_NEED=$(du -s /tmp/merlinclash | awk '{print $1}')
if [ "$SPACE_AVAL" -gt "$SPACE_NEED" ];then
	echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 插件安装需要"$SPACE_NEED" KB，空间满足，继续安装！
	#升级前先删除无关文件,保留已上传配置文件
	# 先关闭clash
	if [ "$me" == "1" ];then
		echo_date 先关闭clash插件，保证文件更新成功!
		[ -f "/jffs/softcenter/merlinclash/clashconfig.sh" ] && sh /jffs/softcenter/merlinclash/clashconfig.sh stop
	fi
	echo_date 清理旧文件,保留已上传配置文件
	rm -rf /jffs/softcenter/merlinclash/Country.mmdb
	rm -rf /jffs/softcenter/merlinclash/GeoIP.dat
        rm -rf /jffs/softcenter/merlinclash/*.yaml
	rm -rf /jffs/softcenter/merlinclash/*.txt
	rm -rf /jffs/softcenter/merlinclash/clashconfig.sh
	rm -rf /jffs/softcenter/merlinclash/version
	rm -rf /jffs/softcenter/merlinclash/yaml_basic/
	rm -rf /jffs/softcenter/merlinclash/yaml_dns/
	rm -rf /jffs/softcenter/merlinclash/dashboard/
	rm -rf /jffs/softcenter/bin/clash
	rm -rf /jffs/softcenter/bin/yq
	rm -rf /jffs/softcenter/bin/jq_c
	rm -rf /jffs/softcenter/bin/haveged_c
        rm -rf /jffs/softcenter/bin/mc_dns2socks
	#------网易云内容-----------
	rm -rf /jffs/softcenter/bin/UnblockNeteaseMusic
	rm -rf /jffs/softcenter/bin/UnblockMusic
	#------网易云内容-----------
	#------koolproxy--------
	[ -L "/jffs/softcenter/bin/koolproxy" ] && rm -rf /jffs/softcenter/bin/koolproxy
	rm -rf /jffs/softcenter/merlinclash/koolproxy
	#------koolproxy--------
	rm -rf /tmp/upload/*.yaml
	rm -rf /jffs/softcenter/webs/Module_merlinclash*
	rm -rf /jffs/softcenter/res/icon-merlinclash.png
	rm -rf /jffs/softcenter/res/clash-kcp.jpg
	rm -rf /jffs/softcenter/res/clash*
	rm -rf /jffs/softcenter/res/china_ip_route.ipset
	rm -rf /jffs/softcenter/res/china_ip_route6.ipset
	#
	rm -rf /jffs/softcenter/res/DisneyPlus_Domains.list
	rm -rf /jffs/softcenter/res/Netflix_Domains.list
	rm -rf /jffs/softcenter/res/Netflix_Domains_Custom.list
	#
        rm -rf /jffs/softcenter/scripts/clash*

	find /jffs/softcenter/init.d/ -name "*clash.sh" | xargs rm -rf
	cd /jffs/softcenter/bin && mkdir -p UnblockMusic && cd
	cd /jffs/softcenter/merlinclash && mkdir -p dashboard && cd
	cd /jffs/softcenter/merlinclash && mkdir -p yaml_basic && cd
	cd /jffs/softcenter/merlinclash/yaml_basic && mkdir -p host && cd
	cd /jffs/softcenter/merlinclash && mkdir -p yaml_dns && cd
	cd /jffs/softcenter/merlinclash && mkdir -p yaml_bak && cd
	cd /jffs/softcenter/merlinclash && mkdir -p yaml_use && cd
	cd /jffs/softcenter/merlinclash && mkdir -p conf && cd
	#增加koolproxy文件夹
	cd /jffs/softcenter/merlinclash && mkdir -p koolproxy && cd
	echo_date 开始复制文件！
	cd /tmp

	echo_date 复制相关二进制文件！此步时间可能较长！
	cp -rf /tmp/merlinclash/clash/clash /jffs/softcenter/bin/
	cp -rf /tmp/merlinclash/clash/mc_dns2socks /jffs/softcenter/bin/
	cp -rf /tmp/merlinclash/clash/yq /jffs/softcenter/bin/
	cp -rf /tmp/merlinclash/clash/jq_c /jffs/softcenter/bin/
	cp -rf /tmp/merlinclash/clash/haveged_c /jffs/softcenter/bin/
	#------网易云内容-----------
	cp -rf /tmp/merlinclash/UnblockMusic/* /jffs/softcenter/bin/UnblockMusic/	
	#------网易云内容-----------
	cp -rf /tmp/merlinclash/conf/* /jffs/softcenter/merlinclash/conf/
	#------koolproxy--------
	cp -rf /tmp/merlinclash/koolproxy/* /jffs/softcenter/merlinclash/koolproxy/
	#------koolproxy--------

	cp -rf /tmp/merlinclash/clash/Country.mmdb /jffs/softcenter/merlinclash/
	cp -rf /tmp/merlinclash/clash/GeoIP.dat /jffs/softcenter/merlinclash/
	cp -rf /tmp/merlinclash/clash/clashconfig.sh /jffs/softcenter/merlinclash/
	cp -rf /tmp/merlinclash/version /jffs/softcenter/merlinclash/

	cp -rf /tmp/merlinclash/yaml_basic/* /jffs/softcenter/merlinclash/yaml_basic/
	cp -rf /tmp/merlinclash/yaml_dns/* /jffs/softcenter/merlinclash/yaml_dns/
	cp -rf /tmp/merlinclash/dashboard/* /jffs/softcenter/merlinclash/dashboard/

	echo_date 复制相关的脚本文件！
	cp -rf /tmp/merlinclash/scripts/* /jffs/softcenter/scripts/
	cp -rf /tmp/merlinclash/install.sh /jffs/softcenter/scripts/merlinclash_install.sh
	cp -rf /tmp/merlinclash/uninstall.sh /jffs/softcenter/scripts/uninstall_merlinclash.sh

	echo_date 复制相关的网页文件！
	cp -rf /tmp/merlinclash/webs/* /jffs/softcenter/webs/
	cp -rf /tmp/merlinclash/res/* /jffs/softcenter/res/
	if [ "$ROG" == "1" ];then
		cp -rf /tmp/merlinclash/rog/res/merlinclash.css /jffs/softcenter/res/
        fi
        if [ "$TUF" == "1" ];then
		sed -i 's/3e030d/3e2902/g;s/91071f/92650F/g;s/680516/D0982C/g;s/cf0a2c/c58813/g;s/700618/74500b/g;s/530412/92650F/g' /tmp/merlinclash/rog/res/merlinclash.css >/dev/null 2>&1
		cp -rf /tmp/merlinclash/rog/res/merlinclash.css /jffs/softcenter/res/
        fi

	echo_date 为新安装文件赋予执行权限...
	chmod 755 /jffs/softcenter/bin/clash
        chmod 755 /jffs/softcenter/bin/mc_dns2socks
	chmod 755 /jffs/softcenter/bin/yq
	chmod 755 /jffs/softcenter/bin/jq_c
	chmod 755 /jffs/softcenter/bin/haveged_c
	chmod 755 /jffs/softcenter/bin/UnblockMusic/*
	chmod 755 /jffs/softcenter/merlinclash/Country.mmdb
	chmod 755 /jffs/softcenter/merlinclash/GeoIP.dat
        chmod 755 /jffs/softcenter/merlinclash/yaml_basic/*
	chmod 755 /jffs/softcenter/merlinclash/yaml_dns/*
	chmod 755 /jffs/softcenter/merlinclash/conf/*
        chmod 755 /jffs/softcenter/merlinclash/koolproxy/*
	chmod 755 /jffs/softcenter/merlinclash/*
	chmod 755 /jffs/softcenter/scripts/clash*
	#RT-AC5300为R8500
	#RT-AC3200为R8000
	if [ "$MODEL" == "R7000" ] || [ "$MODEL" == "RT-AC5300" ] || [ "$MODEL" == "RT-AC3200" ] || [ "$MODEL" == "R6300V2" ] || [ "$MODEL" == "RT-AC68U" ]; then
		ln -sf /jffs/softcenter/bin/koolbox /jffs/softcenter/bin/base64
	fi
	if [ ! -f "/jffs/softcenter/bin/base64_decode" ] && [ -f "/jffs/softcenter/bin/base64_encode" ]; then
		echo_date "创建base64_decode二进制" 
		ln -sf /jffs/softcenter/bin/base64_encode /jffs/softcenter/bin/base64_decode
	elif [ -f "/jffs/softcenter/bin/base64_decode" ]; then
		echo_date "已经存在base64_decode二进制"
	else
		echo_date "机子不存在base64_decode二进制，部分功能将受影响"
	fi
	
	echo_date "创建自启脚本软链接！"
	[ -L "/jffs/softcenter/init.d/S99merlinclash.sh" ] && rm -rf /jffs/softcenter/init.d/S99merlinclash.sh && ln -sf /jffs/softcenter/merlinclash/clashconfig.sh /jffs/softcenter/init.d/S99merlinclash.sh
	[ -L "/jffs/softcenter/init.d/N99merlinclash.sh" ] && rm -rf /jffs/softcenter/init.d/N99merlinclash.sh && ln -sf /jffs/softcenter/merlinclash/clashconfig.sh /jffs/softcenter/init.d/N99merlinclash.sh
	[ ! -L "/jffs/softcenter/init.d/S99merlinclash.sh" ]  && ln -sf /jffs/softcenter/merlinclash/clashconfig.sh /jffs/softcenter/init.d/S99merlinclash.sh
	[ ! -L "/jffs/softcenter/init.d/N99merlinclash.sh" ]  && ln -sf /jffs/softcenter/merlinclash/clashconfig.sh /jffs/softcenter/init.d/N99merlinclash.sh

	echo_date "创建dns文件软链接！"
	[ -L "/tmp/clash_redirhost_view.txt" ] && rm -rf /tmp/clash_redirhost_view.txt && ln -sf /jffs/softcenter/merlinclash/yaml_dns/redirhost.yaml /tmp/clash_redirhost_view.txt
	[ -L "/tmp/clash_redirhostp_view.txt" ] && rm -rf /tmp/clash_redirhostp_view.txt && ln -sf /jffs/softcenter/merlinclash/yaml_dns/redirhostp.yaml /tmp/clash_redirhostp_view.txt
	[ -L "/tmp/clash_fakeip_view.txt" ] && rm -rf /tmp/clash_fakeip_view.txt && ln -sf /jffs/softcenter/merlinclash/yaml_dns/fakeip.yaml /tmp/clash_fakeip_view.txt

	[ ! -L "/tmp/clash_redirhost_view.txt" ] && ln -sf /jffs/softcenter/merlinclash/yaml_dns/redirhost.yaml /tmp/clash_redirhost_view.txt
	[ ! -L "/tmp/clash_redirhostp_view.txt" ] && ln -sf /jffs/softcenter/merlinclash/yaml_dns/redirhostp.yaml /tmp/clash_redirhostp_view.txt
	[ ! -L "/tmp/clash_fakeip_view.txt" ] && ln -sf /jffs/softcenter/merlinclash/yaml_dns/fakeip.yaml /tmp/clash_fakeip_view.txt

	# 离线安装时设置软件中心内储存的版本号和连接
	echo_date 清空冗余值
	dbus remove merlinclash_proxygroup_version
	dbus remove merlinclash_proxygame_version
	dbus remove merlinclash_version_local
	dbus remove merlinclash_patch_version
	dbus remove merlinclash_dashboard_secret
	dbus remove merlinclash_bypassmode
	dbus remove merlinclash_dc_ss
	dbus remove merlinclash_dc_v2
	dbus remove merlinclash_dc_trojan
	dbus remove merlinclash_links
	dbus remove merlinclash_links2
	dbus remove merlinclash_kcp_param_2
	dbus remove merlinclash_dc_name
	dbus remove merlinclash_dc_passwd
	dbus remove merlinclash_dc_token
	dbus remove merlinclash_dnsedit_tag
	dbus remove merlinclash_dns_edit_content1
	dbus remove merlinclash_host_content1
	dbus remove merlinclash_host_content1_tmp
	dbus remove softcenter_module_merlinclash_install
	dbus remove softcenter_module_merlinclash_version
	dbus remove merlinclash_mark_MD51
	acls=`dbus list merlinclash_acl_ | cut -d "=" -f 1`
	for acl in $acls
	do
		#echo_date 移除$acl 
		dbus remove $acl
	done
	devs=`dbus list merlinclash_device_ | cut -d "=" -f 1`
	for dev in $devs
	do
		#echo_date 移除$acl 
		dbus remove $dev
	done
	wls=`dbus list merlinclash_whitelist_ | cut -d "=" -f 1`
	for wl in $wls
	do
		dbus remove $wl
	done
	ips=`dbus list merlinclash_ipport_ | cut -d "=" -f 1`
	for ip in $ips
	do
		dbus remove $ip
	done
	kps=`dbus list merlinclash_koolproxy_ | cut -d "=" -f 1`
	for kp in $kps
	do
		dbus remove $kp
	done
	kpas=`dbus list merlinclash_kpacl_ | cut -d "=" -f 1`
	for kpa in $kpas
	do
		dbus remove $kpa
	done
	nokpas=`dbus list merlinclash_nokpacl_ | cut -d "=" -f 1`
	for nokpa in $nokpas
	do
		dbus remove $nokpa
	done
	echo_date 设置相关参数初始值！
	CUR_VERSION=$(cat /jffs/softcenter/merlinclash/version)
	[ ! -L "/jffs/softcenter/bin/koolproxy" ] && ln -sf /jffs/softcenter/merlinclash/koolproxy/koolproxy /jffs/softcenter/bin/koolproxy	
	kpversion="$(/jffs/softcenter/merlinclash/koolproxy/koolproxy -v)"
	if [ -n "$kpversion" ]; then
		kpv="$kpversion"		
	else
		kpv="null"
	fi
	[ ! -L "/jffs/softcenter/bin/UnblockNeteaseMusic" ] && ln -sf /jffs/softcenter/merlinclash/UnblockMusic/UnblockNeteaseMusic /jffs/softcenter/bin/UnblockNeteaseMusic
	unmversion=$(/jffs/softcenter/bin/UnblockNeteaseMusic -v 2>/dev/null | head -n 1 | cut -d " " -f2)
	if [ -n "$unmversion" ]; then
		unmv="$unmversion"
	else
		unmv="null"
	fi
	echo_date "数据初始化"
	dbus set merlinclash_koolproxy_version=$kpv
	dbus set merlinclash_UnblockNeteaseMusic_version=$unmv
	dbus set merlinclash_version_local="$CUR_VERSION"
	dbus set merlinclash_patch_version="000"
	dbus set softcenter_module_merlinclash_install="1"
	dbus set softcenter_module_merlinclash_version="$CUR_VERSION"
	dbus set softcenter_module_merlinclash_title="Merlin Clash [3in1]"
	dbus set softcenter_module_merlinclash_description="Merlin Clash:一个基于规则的代理程序，支持多种协议~"
	#dbus set merlinclash_proxygroup_version="2021011601"
	dbus set softcenter_module_merlinclash_home_url="Module_merlinclash.asp"
	#dbus set merlinclash_proxygame_version="2020070101"
	dbus set merlinclash_dnsedit_tag="redirhost"
	dbus set merlinclash_bypassmode="1"
	dbus set merlinclash_dc_name=""
	dbus set merlinclash_dc_passwd=""
	dbus set merlinclash_dc_token=""
	dbus set merlinclash_flag="380"
	dbus set merlinclash_kpacl_default_mode="1"
	dbus set merlinclash_mark_MD51=""
	dbus set merlinclash_check_clashimport=1 #导入CLASH
	dbus set merlinclash_check_sclocal=1	#SUBC/ACL转换
	dbus set merlinclash_check_ssimport=1	#导入科学节点
	dbus set merlinclash_check_upcusrule=0	#上传自定订阅
	dbus set merlinclash_check_xiaobai=1	#小白一键订阅
	dbus set merlinclash_check_yamldown=1 #YAML下载
	dbus set merlinclash_check_kcp=0	#KCP加速
	dbus set merlinclash_check_kp=0		#护网大师
	dbus set merlinclash_check_noipt=0 	#透明代理
	dbus set merlinclash_check_aclrule=0 	#自定规则
	dbus set merlinclash_check_cdns=0 	#DNS编辑区
	dbus set merlinclash_check_cdns=0 	#HOST编辑区
	dbus set merlinclash_check_scriptedit=0 	#script编辑区
	dbus set merlinclash_check_ipsetproxy=0 	#转发clash
	dbus set merlinclash_check_ipsetproxyarround=0 	#绕过clash
	dbus set merlinclash_check_controllist=0 	#黑白郎君
	dbus set merlinclash_check_cusport=0 	#自定义端口
	dbus set merlinclash_check_dlercloud=0 	#DC用户
	dbus set merlinclash_check_tproxy=0 	#TPROXY
	dbus set merlinclash_check_unblock=0 	#云村解锁
	dbus set merlinclash_cirswitch=1 #大陆绕行IP 强制打开
	dbus set merlinclash_check_notice_show=1 #通知广告区

	dbus set merlinclash_links=" "
	dbus set merlinclash_links2=" "
	dbus set merlinclash_links3=" "
	dbus set merlinclash_dnsclear="1"
	dbus set merlinclash_linuxver="$LINUX_VER"
	dbus set merlinclash_tproxymode="closed"
	dbus set merlinclash_ipv6switch="0"
	dbus set merlinclash_iptablessel="fangan1"
	dbus set merlinclash_d2s="0"

	merlinclash_clash_version_tmp=$(/jffs/softcenter/bin/clash -v 2>/dev/null | head -n 1 | cut -d " " -f2)
	if [ -n "$merlinclash_clash_version_tmp" ]; then
		mcv="$merlinclash_clash_version_tmp"		
	else
		mcv="null"
	fi
	dbus set merlinclash_clash_version="$mcv"
	#提取配置认证码
	secret=$(cat /jffs/softcenter/merlinclash/yaml_basic/head.yaml | awk '/secret:/{print $2}' | sed 's/"//g')
	dbus set merlinclash_dashboard_secret="$secret"

	echo_date 一点点清理工作...
	rm -rf /tmp/clash* >/dev/null 2>&1

	echo_date clash插件安装成功！
	#yaml不为空则复制文件 然后生成yamls.txt
	dir=/jffs/softcenter/merlinclash/yaml_bak
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]
	then
		cp -rf /jffs/softcenter/merlinclash/yaml_bak/*.yaml  /jffs/softcenter/merlinclash/yaml_use/
	fi
	
		
	#生成新的txt文件

	rm -rf /jffs/softcenter/merlinclash/yaml_bak/yamls.txt
	echo_date "初始化yaml文件列表"
	find /jffs/softcenter/merlinclash/yaml_bak/  -name "*.yaml" |sed 's#.*/##' |sed '/^$/d' | awk -F'.' '{print $1}' > /jffs/softcenter/merlinclash/yaml_bak/yamls.txt
	#创建软链接
	ln -sf /jffs/softcenter/merlinclash/yaml_bak/yamls.txt /tmp/yamls.txt
	#
	echo_date "初始化host文件列表"
	find /jffs/softcenter/merlinclash/yaml_basic/host/  -name "*.yaml" |sed 's#.*/##' |sed '/^$/d' | awk -F'.' '{print $1}' > /jffs/softcenter/merlinclash/yaml_basic/host/hosts.txt
	#创建软链接
	ln -sf /jffs/softcenter/merlinclash/yaml_basic/host/hosts.txt /tmp/clash_hosts.txt
	dbus set merlinclash_hostsel="default"
	echo_date "初始化配置文件处理完成"

	if [ "$me" == "1" ];then
		echo_date 重启clash插件！
		sh /jffs/softcenter/scripts/clash_config.sh start start
	fi

	echo_date 更新完毕，请等待网页自动刷新！
else
	echo_date 当前jffs分区剩余"$SPACE_AVAL" KB, 插件安装需要"$SPACE_NEED" KB，空间不足！
	echo_date 退出安装！
	exit 1
fi
