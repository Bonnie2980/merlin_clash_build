#!/bin/sh

export KSROOT=/jffs/softcenter
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'

if [ "$merlinclash_enable" == "1" ] && [ "$merlinclash_watchdog" == "1" ];then
		sed -i '/clash_watchdog/d' /var/spool/cron/crontabs/* >/dev/null 2>&1
		watcdogtime=$merlinclash_watchdog_delay_time
		cru a clash_watchdog "*/$watcdogtime * * * * /bin/sh /jffs/softcenter/scripts/clash_watchdog.sh"
	#	/bin/sh /jffs/softcenter/scripts/clash_watchdog.sh >/dev/null 2>&1 &
else
	#pid_watchdog=$(ps | grep clash_watchdog.sh | grep -v grep | awk '{print $1}')
	#if [ -n "$pid_watchdog" ]; then
	#echo_date 关闭看门狗... >> $LOG_FILE
	# 有时候killall杀不了v2ray进程，所以用不同方式杀两次
	#kill -9 "$pid_watchdog" >/dev/null 2>&1
	sed -i '/clash_watchdog/d' /var/spool/cron/crontabs/* >/dev/null 2>&1
	#fi
fi

